# prototying_cphfw
A study project: prototype of a digital solution for Copenghagen  Fashion Week. 

Progress in files:
https://docs.google.com/spreadsheets/d/100DvNQCeVgbb9nKxXUsY0cdaUYORUuHvKbD_A94st6A/edit?gid=0#gid=0 

This GDrive file is a list of files (we will have a lot of them lol), to make it easier let's mark the status of work and whoever is working on what and what is the status and whatever ongoing notes we have.
